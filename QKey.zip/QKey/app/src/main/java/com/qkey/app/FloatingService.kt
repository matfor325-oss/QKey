package com.qkey.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import kotlin.math.abs

class FloatingService : Service() {

    private var wm: WindowManager? = null
    private var button: View? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    // رقم المفتاح (Q = 45). غيّره هنا إذا أردت حرفًا آخر.
    private val keyCode = KeyEvent.KEYCODE_Q

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        if (button == null) addButton()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("float", "الزر العائم", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "float")
            .setContentTitle("زر Q يعمل")
            .setContentText("اضغط هنا لإيقاف الزر")
            .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel)
            .setContentIntent(stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addButton() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val size = (60 * resources.displayMetrics.density).toInt()

        val tv = TextView(this)
        tv.text = "Q"
        tv.textSize = 24f
        tv.setTextColor(Color.WHITE)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xAA222222.toInt())
        bg.setStroke(4, Color.WHITE)
        tv.background = bg

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.LEFT
        lp.x = 120
        lp.y = 400

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    v.alpha = 0.6f
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        manager.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.alpha = 1f
                    if (!moved) sendKey()
                }
                MotionEvent.ACTION_CANCEL -> v.alpha = 1f
            }
            true
        }

        manager.addView(tv, lp)
        button = tv
    }

    private fun msg(text: String) {
        handler.post { Toast.makeText(this, text, Toast.LENGTH_SHORT).show() }
    }

    private fun sendKey() {
        val ok = try {
            Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
        if (!ok) {
            msg("Shizuku غير مشغّل أو بدون إذن")
            return
        }
        exec.execute {
            try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                m.isAccessible = true
                val args: Array<Any?> =
                    arrayOf(arrayOf("input", "keyevent", keyCode.toString()), null, null)
                val p = m.invoke(null, *args) as Process
                p.waitFor()
            } catch (e: Throwable) {
                msg("تعذر إرسال المفتاح: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        button?.let { wm?.removeView(it) }
        button = null
        exec.shutdown()
        super.onDestroy()
    }
}
