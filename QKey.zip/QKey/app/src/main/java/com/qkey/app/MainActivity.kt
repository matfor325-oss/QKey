package com.qkey.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val reqCode = 1001

    private val permListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderListener =
        Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener =
        Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    private fun shizukuGranted(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun overlayGranted(): Boolean = Settings.canDrawOverlays(this)

    private fun makeButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(10)
        b.layoutParams = lp
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(40), dp(20), dp(20))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val title = TextView(this)
        title.text = "زر Q العائم"
        title.textSize = 24f
        root.addView(title)

        status = TextView(this)
        status.textSize = 16f
        status.setPadding(0, dp(12), 0, dp(12))
        root.addView(status)

        root.addView(makeButton("1) فتح تطبيق Shizuku") {
            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i == null) toast("تطبيق Shizuku غير مثبّت") else startActivity(i)
        })
        root.addView(makeButton("2) منح إذن Shizuku لهذا التطبيق") {
            when {
                !shizukuReady() -> toast("شغّل Shizuku أولًا")
                shizukuGranted() -> toast("الإذن ممنوح مسبقًا")
                else -> Shizuku.requestPermission(reqCode)
            }
        })
        root.addView(makeButton("3) السماح بالظهور فوق التطبيقات") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        })
        root.addView(makeButton("4) تشغيل الزر العائم") {
            when {
                !overlayGranted() -> toast("امنح إذن الظهور فوق التطبيقات أولًا")
                !shizukuGranted() -> toast("شغّل Shizuku وامنحه الإذن أولًا")
                else -> startForegroundService(Intent(this, FloatingService::class.java))
            }
        })
        root.addView(makeButton("إيقاف الزر العائم") {
            stopService(Intent(this, FloatingService::class.java))
        })

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text =
            "Shizuku يعمل: ${mark(shizukuReady())}\n" +
                "إذن Shizuku: ${mark(shizukuGranted())}\n" +
                "الظهور فوق التطبيقات: ${mark(overlayGranted())}"
    }
}
